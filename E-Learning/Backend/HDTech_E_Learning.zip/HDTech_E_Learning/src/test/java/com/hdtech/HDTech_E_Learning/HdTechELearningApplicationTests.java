package com.hdtech.HDTech_E_Learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HdTechELearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
