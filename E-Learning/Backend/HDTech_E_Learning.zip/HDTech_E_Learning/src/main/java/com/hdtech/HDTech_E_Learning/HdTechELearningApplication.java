package com.hdtech.HDTech_E_Learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HdTechELearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(HdTechELearningApplication.class, args);
	}

}
